﻿namespace CMCS.Models.Enums
{
    public enum ClaimPostStatus
    {
        NotPosted = 0,
        Posted = 1
    }
}