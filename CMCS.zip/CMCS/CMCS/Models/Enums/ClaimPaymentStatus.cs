﻿namespace CMCS.Models.Enums
{
    public enum ClaimPaymentStatus
    {
            Unpaid = 0,
            Paid = 1       // Student
    }
}
