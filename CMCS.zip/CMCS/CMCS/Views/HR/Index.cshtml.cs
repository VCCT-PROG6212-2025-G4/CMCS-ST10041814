using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CMCS.Views.HR
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
