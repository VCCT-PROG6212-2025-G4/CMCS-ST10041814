using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CMCS.Views.HR
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
