using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CMCS.Views.Account
{
    public class RegisterModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
