using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CMCS.Views.Claim
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
