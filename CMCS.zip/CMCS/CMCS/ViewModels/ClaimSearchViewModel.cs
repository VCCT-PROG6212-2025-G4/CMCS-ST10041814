﻿public class ClaimSearchViewModel
{
    // get key word and filter 
    public string? Keyword { get; set; }  
    public string? SearchBy { get; set; }  // UserId / Username / Lecturer / Month / Year
}

